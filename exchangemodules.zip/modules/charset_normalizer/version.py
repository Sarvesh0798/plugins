"""
Expose version
"""

__version__ = "2.0.10"
VERSION = __version__.split(".")
